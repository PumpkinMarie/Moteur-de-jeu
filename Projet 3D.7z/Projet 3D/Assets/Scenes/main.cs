﻿ using UnityEngine;
 using System.Collections;
     
[RequireComponent(typeof(Rigidbody))]

public class main : MonoBehaviour {
 
	 public Vector3 jump;
	 public float jumpForce = 1.3f;
 	 public float slideForce = 0.2f;
	 public int semLeft=1;
	 public int semRight=1;
 
	 Rigidbody rb;
	 void Start(){
		 rb = GetComponent<Rigidbody>();
		 jump = new Vector3(0.0f, 2.0f, 0.0f);
	 }
 
	 private bool isGrounded() {
			Vector3 down = transform.TransformDirection(Vector3.down);
			return(Physics.Raycast(transform.position + 0.1f * Vector3.up, down, 0.1f));
	 }
 
	 void FixedUpdate(){
		 if(Input.GetKeyDown(KeyCode.Space) && isGrounded()){
			 rb.AddForce(jump * jumpForce, ForceMode.Impulse);
 		 }
		 if(Input.GetKeyDown(KeyCode.RightArrow) && isGrounded() && semRight>0){
			transform.Translate(Vector3.left * slideForce);
			semRight--;
			semLeft++;
 		 }
		 if(Input.GetKeyDown(KeyCode.LeftArrow) && isGrounded() && semLeft>0){
			transform.Translate(Vector3.right * slideForce);
			semLeft--;semRight++;
 		 }
	 }
	 private bool isCollision() {
			Vector3 down = transform.TransformDirection(Vector3.down);
			return(Physics.Raycast(transform.position + 0.1f * Vector3.up, down, 0.1f));
			Debug.DrawRay(transform.position + 0.1f * Vector3.up,down,Color.yellow);
	 }
 }
