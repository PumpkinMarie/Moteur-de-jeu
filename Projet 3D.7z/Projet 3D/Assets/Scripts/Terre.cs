﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Terre : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	float angle = 360.0f; // Degree per time unit
	float time = 10f; // Time unit in sec
	Vector3 axis = Vector3.up; // Rotation axis, here it the yaw axis
 
	private void Update()
	{
		GetComponent<Transform>().RotateAround(Vector3.zero, axis, angle * Time.deltaTime / time);
	}
}
